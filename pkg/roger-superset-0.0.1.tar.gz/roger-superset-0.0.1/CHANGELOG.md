## Release 0.0.1
### Summary

Adds several new features and updates

### Features
- Deprecation function X in favor of Y.
- Updated Gemfile to deal with parallel_tests Ruby dependancy

### Bugfixes
- README typo fixes.
- Updates deprecation tests to include future parser.


This changelog is used track changes with this module in human readable format.
Feel free to reference tickets with links or other important information the 
reader would find useful when determining the level of risk with upgrading.
For more information on changelogs please [see the keeping a changelog site](http://keepachangelog.com/en/0.3.0/). 